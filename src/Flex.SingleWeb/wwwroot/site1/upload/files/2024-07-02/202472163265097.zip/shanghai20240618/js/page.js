$(function () {

  var interleaveOffset = 0.3; //视差比值
  var main = {
    speed: 800,
    grabCursor: true,
    watchSlidesProgress: true,
    keyboardControl: true,
    mousewheel: true,
    direction: "vertical",
    slidesPerView: "auto",
    simulateTouch: false,
    followFinger: false,
    observer: true,
    observeParents: true,
    observeSlideChildren: true,
    keyboard: true,
    on: {
      init: function () {
        swiperAnimateCache(this);
        this.emit("slideChangeTransitionEnd");
        var i = this.realIndex;
        if(i == 0) {
          $('.back').addClass('hide');
        }else {
          $('.back').removeClass('hide');
        }
      },
      progress: function () {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          var slideProgress = swiper.slides[i].progress;
          var innerOffset = swiper.width * interleaveOffset;
          var innerTranslate = slideProgress * innerOffset;
          swiper.slides[i].querySelector(".inner").style.transform =
            "translate3d(0," + innerTranslate + "px,  0)";
        }
      },
      touchStart: function () {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          swiper.slides[i].style.transition = "";
        }
      },
      setTransition: function (speed) {
        var swiper = this;
        for (var i = 0; i < swiper.slides.length; i++) {
          swiper.slides[i].style.transition = speed + "ms";
          swiper.slides[i].querySelector(".inner").style.transition =
            speed + "ms";
        }
      },
      transitionStart: function () {
        var i = this.realIndex;
        if(i == 0) {
          $('.back').addClass('hide');
        }else {
          $('.back').removeClass('hide');
        }
      },
      slideChangeTransitionEnd: function () {
        swiperAnimate(this);
      }
    }
  };

  var main = new Swiper(".main-swiper", main);

  $('.main1 .item,.pagis .num').on('click', function () {
    var i = $(this).index() + 1;
    main.slideTo(i, 800, false);
  })
  $('.back').on('click', function () {
    main.slideTo(0, 800, false);
    $('.back').addClass('hide');
  })


  var lunbo = new Swiper('.com .lunbo-swiper', {
    speed: 600,
    loop: true,
    spaceBetween: 5,
    navigation: {
      nextEl: '.lunbo-wrap .swiper-button-next',
      prevEl: '.lunbo-wrap .swiper-button-prev',
    },
    autoplay: {
      delay: 5000,
      stopOnLastSlide: false,
      disableOnInteraction: false,
    },
  });
  var lunbo2 = new Swiper('.lunbo-swiper2', {
    speed: 600,
    loop: true,
    effect: 'fade',
    spaceBetween: 5,
    navigation: {
      nextEl: '.lunbo-wrap .swiper-button-next',
      prevEl: '.lunbo-wrap .swiper-button-prev',
    },
    autoplay: {
      delay: 6000,
      stopOnLastSlide: false,
      disableOnInteraction: false,
    },
  });
  var lunbo3 = new Swiper('.main6 .jx-lunbo2', {
    speed: 600,
    loop: true,
    spaceBetween: 5,
    navigation: {
      nextEl: '.main6 .lunbo-ce .swiper-button-next',
      prevEl: '.main6 .lunbo-ce .swiper-button-prev',
    },
    autoplay: {
      delay: 6000,
      stopOnLastSlide: false,
      disableOnInteraction: false,
    },
  });
  var lunbo4 = new Swiper('.main6 .jx-lunbo1', {
    speed: 600,
    loop: true,
    spaceBetween: 5,
    navigation: {
      nextEl: '.main6 .lunbo-wrap1 .swiper-button-next',
      prevEl: '.main6 .lunbo-wrap1 .swiper-button-prev',
    },
    autoplay: {
      delay: 4000,
      stopOnLastSlide: false,
      disableOnInteraction: false,
    },
  });
})